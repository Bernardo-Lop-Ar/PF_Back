﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Biblioteca.Models;

namespace Biblioteca.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BibliotecaController : ControllerBase
    {
        private static List<Livros> livros = new List<Livros>
        {
            new Livros
            {
                Id = 1,
                Titulo = "Dom Casmurro",
                Autor = "Machado de Assis",
                AnoLancamento = 1899,
                Qtd = 2

            },
            new Livros
            {

            }
        };


    }
}
