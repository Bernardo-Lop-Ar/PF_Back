﻿namespace Biblioteca.Models
{
    public class Locatario
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
        public int AnoNasc { get; set; }
    }
}
